import { Invoicedetail } from './invoicedetail';

describe('Invoicedetail', () => {
  it('should create an instance', () => {
    expect(new Invoicedetail()).toBeTruthy();
  });
});
