import { Multiobjectpost } from './multiobjectpost';

describe('Multiobjectpost', () => {
  it('should create an instance', () => {
    expect(new Multiobjectpost()).toBeTruthy();
  });
});
