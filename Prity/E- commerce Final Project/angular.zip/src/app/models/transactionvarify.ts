export class Transactionvarify {
     serialnumber:any;
     mobilenumber: any;
     transactionid: any;
     transactionamount: any;

     constructor(serialnumber:any,mobilenumber: any, transactionid: any, transactionamount: any) {
          this.serialnumber=serialnumber;
          this.mobilenumber = mobilenumber;
          this.transactionid = transactionid;
          this.transactionamount = transactionamount;
     }
}