export class Admin {

  id: any;
  password: any;
  name: any;
  gender: any;
  email: any;
  address: any;
  phone: any;

  constructor(id: any, password: any, name: any, gender: any, email: any, address: any, phone: any) {
    this.id = id;
    this.password = password;
    this.name = name;
    this.gender = gender;
    this.email = email;
    this.address = address;
    this.phone = phone;
  }

}