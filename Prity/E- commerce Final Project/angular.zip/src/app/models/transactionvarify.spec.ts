import { Transactionvarify } from './transactionvarify';

describe('Transactionvarify', () => {
  it('should create an instance', () => {
    expect(new Transactionvarify()).toBeTruthy();
  });
});
