import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerbalancecheck',
  templateUrl: './customerbalancecheck.component.html',
  styleUrls: ['./customerbalancecheck.component.css']
})
export class CustomerbalancecheckComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
