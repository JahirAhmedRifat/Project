import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cutomerbalancecheck',
  templateUrl: './cutomerbalancecheck.component.html',
  styleUrls: ['./cutomerbalancecheck.component.css']
})
export class CutomerbalancecheckComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
