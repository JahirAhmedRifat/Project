import { Createaccount } from './createaccount';

describe('Createaccount', () => {
  it('should create an instance', () => {
    expect(new Createaccount()).toBeTruthy();
  });
});
