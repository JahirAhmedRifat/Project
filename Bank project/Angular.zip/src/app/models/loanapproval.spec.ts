import { Loanapproval } from './loanapproval';

describe('Loanapproval', () => {
  it('should create an instance', () => {
    expect(new Loanapproval()).toBeTruthy();
  });
});
