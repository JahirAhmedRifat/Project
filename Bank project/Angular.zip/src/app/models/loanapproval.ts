export class Loanapproval {

  accnumber: any;
  password: any;
  nid: any;
  loantype: any;
  req_amount: any;
  duration: any;
  cash: any;
  interest_rate: any;
  total_amount: any;
  installment: any;
  paid_installment: any;
  monthlypaid: any;
  paid_amount: any;
  due: any;
  name: any;
  gender: any;
  mobile: any;
  email: any;
  address: any;
  date: any;
  mar_status: any;
  occupation: any;
  
  constructor(accnumber: any, password: any, nid: any, loantype: any, req_amount: any, duration: any,
    cash: any, interest_rate: any, total_amount: any, installment: any, paid_installment: any,
    monthlypaid: any, paid_amount: any, due: any, name: any, gender: any, mobile: any, email: any,
    address: any, date: any, mar_status: any, occupation: any) {

    this.accnumber = accnumber;
    this.password = password;
    this.nid = nid;
    this.loantype = loantype;
    this.req_amount = req_amount;
    this.duration = duration;
    this.cash = cash;
    this.interest_rate = interest_rate;
    this.total_amount = total_amount;
    this.installment = installment;
    this.paid_installment = paid_installment;
    this.monthlypaid = monthlypaid;
    this.paid_amount = paid_amount;
    this.due = due;
    this.name = name;
    this.gender = gender;
    this.mobile = mobile;
    this.email = email;
    this.address = address;
    this.date = date;
    this.mar_status = mar_status;
    this.occupation = occupation;
  }


}
