export class Admin {
  id: any;
  password: any;
  name: any;
  gender: any;
  email: any;
  phone: any;
  address: any;

  constructor(id: any, password: any, name: any, gender: any, email: any, phone: any, address: any) {
    this.id = id;
    this.password = password;
    this.name = name;
    this.gender = gender;
    this.email = email;
    this.phone = phone;
    this.address = address;
  }

}
