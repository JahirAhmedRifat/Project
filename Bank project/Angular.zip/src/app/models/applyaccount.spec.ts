import { Applyaccount } from './applyaccount';

describe('Applyaccount', () => {
  it('should create an instance', () => {
    expect(new Applyaccount()).toBeTruthy();
  });
});
