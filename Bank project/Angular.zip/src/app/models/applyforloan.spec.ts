import { Applyforloan } from './applyforloan';

describe('Applyforloan', () => {
  it('should create an instance', () => {
    expect(new Applyforloan()).toBeTruthy();
  });
});
