import { Loantransaction } from './loantransaction';

describe('Loantransaction', () => {
  it('should create an instance', () => {
    expect(new Loantransaction()).toBeTruthy();
  });
});
