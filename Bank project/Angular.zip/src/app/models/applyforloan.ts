export class Applyforloan {

  nid: any;
  loantype: any;
  name: any;
  gender: any;
  mobile: any;
  email: any;
  address: any;
  date: any;
  mar_status: any;
  occupation: any;
  amount: any;
  duration: any;

  constructor(nid: any, loantype: any, name: any, gender: any, mobile: any, email: any, address: any, date: any, mar_status: any, occupation: any, amount: any, duration: any) {
    this.nid = nid;
    this.loantype = loantype;
    this.name = name;
    this.gender = gender;
    this.mobile = mobile;
    this.email = email;
    this.address = address;
    this.date = date;
    this.mar_status = mar_status;
    this.occupation = occupation;
    this.amount = amount;
    this.duration = duration;
  }

}